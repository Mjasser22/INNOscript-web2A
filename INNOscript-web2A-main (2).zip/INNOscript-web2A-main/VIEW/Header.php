<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">las aguilas</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="ListDestination.php">Liste des destinations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="AddDestination.php" target="_blank">Ajouter une destination</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Listreservation.php">Liste des réservations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="addreservation.php" target="_blank">Ajouter une réservation</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
