<?php
// Include the destination controller
include '../Controller/destinationC.php';

// Check if the ID parameter is set in the URL
if (isset($_GET['id'])) {
    // Get the destination ID from the URL
    $destinationId = $_GET['id'];

    // Instantiate the destination controller
    $destinationC = new DestinationC();

    // Récupérer la liste des destinations
    $destinationList = $destinationC->listDestinations();

    // Initialize the destination variable
    $destination = null;

    // Find the destination in the destination list by ID
    foreach ($destinationList as $dest) {
        if ($dest['id'] == $destinationId) {
            $destination = $dest;
            break;
        }
    }

    // Check if the destination exists
    if ($destination) {
        // Check if the form is submitted for updating the destination
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Retrieve the updated description and price from the form
            $description = $_POST['description'];
            $price = $_POST['price'];

            // Update the destination in the database
            $destinationC->updateDestination($destinationId, $description, $price);

            // Redirect back to the destination list page
            header("Location: listDestination.php");
            exit();
        }
    } else {
        // Handle the case if the destination does not exist
        echo "Destination not found.";
        exit();
    }
} else {
    // Handle the case if the ID parameter is not set in the URL
    echo "Destination ID is missing.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destination List</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Datatables CSS -->
    <link href="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.css" rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" href="./css/style.css">
</head></head>
<body>
    <?php include 'Header.php'; ?>

    <div class="container">
        <h2>Update Destination</h2>
        <form method="post">
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="form-control" id="description" name="description" required><?php echo $destination['description']; ?></textarea>
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" class="form-control" id="price" name="price" value="<?php echo $destination['price']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>

    <!-- Include necessary scripts -->
</body>
</html>