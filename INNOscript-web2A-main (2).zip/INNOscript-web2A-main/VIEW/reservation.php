<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WoOx Travel Reservation Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-woox-travel.css">
</head>

<body>

    <!-- ***** Header Area Start ***** -->
    <!-- Header code here -->
    <!-- ***** Header Area End ***** -->

    <div class="second-page-heading">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Make Your Reservation</h2>
                </div>
            </div>
        </div>
    </div>

    <div class="reservation-form">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <form id="reservation-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group">
        <label for="destination_id">Destination ID:</label>
        <select id="destination_id" name="destination_id" class="form-control" required>
            <?php
            // Connect to the database
            $host = 'localhost';
            $dbname = 'isra';
            $username = 'root';
            $password = '';

            try {
                $db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                // Fetch destination IDs from the destination table
                $stmt = $db->query("SELECT id FROM destination");
                $destinations = $stmt->fetchAll(PDO::FETCH_ASSOC);

                // Populate the dropdown menu with destination IDs
                foreach ($destinations as $destination) {
                    echo "<option value='{$destination['id']}'>{$destination['id']}</option>";
                }
            } catch (PDOException $e) {
                echo "Connection failed: " . $e->getMessage();
                exit;
            }
            ?>
        </select>
    </div>
                                <div class="form-group">
                                    <label for="user_name">Your Name:</label>
                                    <input type="text" id="user_name" name="user_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="phone_number">Phone Number:</label>
                                    <input type="text" id="phone_number" name="phone_number" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="check_in_date">Check-in Date:</label>
                                    <input type="date" id="check_in_date" name="check_in_date" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="check_out_date">Check-out Date:</label>
                                    <input type="date" id="check_out_date" name="check_out_date" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="accomodation_type">Accommodation Type:</label>
                                    <select id="accomodation_type" name="accomodation_type" class="form-control" required>
                                        <option value="Hotel">Hotel</option>
                                        <option value="Resort">Resort</option>
                                        <option value="Apartment">Apartment</option>
                                        <option value="Villa">Villa</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="total_price">Total Price:</label>
                                    <input type="text" id="total_price" name="total_price" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit Reservation</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <!-- Footer code here -->

    <!-- Scripts -->
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $host = 'localhost';
    $dbname = 'isra';
    $username = 'root';
    $password = '';

    try {
        $db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        exit;
    }

    // Retrieve form data
    $destination_id = $_POST['destination_id'];
    $user_name = $_POST['user_name'];
    $phone_number = $_POST['phone_number'];
    $check_in_date = $_POST['check_in_date'];
    $check_out_date = $_POST['check_out_date'];
    $accomodation_type = $_POST['accomodation_type'];
    $total_price = $_POST['total_price'];

    // Prepare SQL statement
    $sql = "INSERT INTO reservation (destination_id, user_name, phone_number, check_in_date, check_out_date, accomodation_type, total_price) 
            VALUES (:destination_id, :user_name, :phone_number, :check_in_date, :check_out_date, :accomodation_type, :total_price)";

    $stmt = $db->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':destination_id', $destination_id);
    $stmt->bindParam(':user_name', $user_name);
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->bindParam(':check_in_date', $check_in_date);
    $stmt->bindParam(':check_out_date', $check_out_date);
    $stmt->bindParam(':accomodation_type', $accomodation_type);
    $stmt->bindParam(':total_price', $total_price);

    // Execute the statement
    if ($stmt->execute()) {
        // Insertion successful
        echo "<script>alert('Reservation successfully added!');</script>";

    } else {
        // Insertion failed
        echo "<script>alert('Error adding reservation.');</script>";
    }
}
?>
