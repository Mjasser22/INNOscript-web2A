<?php
include '../Controller/DestinationC.php';

// Instanciation du contrôleur de destination
$destinationC = new DestinationC();

// Récupération de la liste des destinations
$destinationList = $destinationC->listDestinations();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Title</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-woox-travel.css">
    <!-- Add isra.css file -->
    <link rel="stylesheet" href="isra.css">
</head>

<body>
    <div class="navigation">
        <ul>
            <li>
                <a href="#">
                    <span class="icon">
                    <ion-icon name="clipboard-outline"></ion-icon>
                    </span>
                    <span class="title">Welcome to your Dashboard </span>
                </a>
            </li>
            <li>
                <a href="liste_employe.php">
                    <span class="icon">
                    <ion-icon name="home-outline"></ion-icon>
                    </span>
                    <span class="title">Search: Filter data</span>
                </a>
                
                <input type="text" placeholder="Search with speciality" id="speciality" onkeyup="filterTable()">
            </li>

            <li>
                <a href="destination.html">
                    <span class="icon">
                        <ion-icon name="people-outline"></ion-icon>
                    </span>
                    <span class="title">Add destination</span>
                </a>
            </li>

            <li>
                <a href="../view/export_pdf.php">
                    <span class="icon">
                        <ion-icon name="chatbubble-outline"></ion-icon>
                    </span>
                    <span class="title">Export PDF</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="icon">
                        <ion-icon name="help-outline"></ion-icon>
                    </span>
                    <span class="title">Help</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="icon">
                        <ion-icon name="settings-outline"></ion-icon>
                    </span>
                    <span class="title">Settings</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="icon">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                    </span>
                    <span class="title">Password</span>
                </a>
            </li>

            <li>
                <a href="login.html">
                    <span class="icon">
                        <ion-icon name="log-out-outline"></ion-icon>
                    </span>
                    <span class="title">Sign Out</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Bouton pour déclencher l'ajout d'une nouvelle destination -->
    <a href="destination.php" class="btn btn-dark">Add New Destination</a>

    <div class="container">
        <table class="table" id="myTable" style="width:85%;">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Country</th>
                    <th>City</th>
                    <th>Region</th>
                    <th>Availability</th>
                    <th>Price</th>
                    <th>Image URL</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($destinationList as $destination) : ?>
                    <tr>
                        <td><?= $destination['id']; ?></td>
                        <td><?= $destination['name']; ?></td>
                        <td><?= $destination['description']; ?></td>
                        <td><?= $destination['country']; ?></td>
                        <td><?= $destination['city']; ?></td>
                        <td><?= $destination['region']; ?></td>
                        <td><?= $destination['availability']; ?></td>
                        <td><?= $destination['price']; ?></td>
                        <td><?= $destination['image_url']; ?></td>
                        <td align="center">
                            <a href="updatedestination.php?id=<?= $destination['id']; ?>" class="btn"><i class="fas fa-pencil-alt fa-xl"></i> Update</a>
                            <a href="DeleteDestination.php?id=<?= $destination['id']; ?>" class="btn"><i class="fas fa-trash fa-xl"></i> Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <!-- Jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Datatables JS -->
    <script src="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.js"></script>
    <!-- Custom JS -->
    <script>
        $(document).ready( function () {
            $('#myTable').DataTable();
        });
    </script>
</body>
</html>
