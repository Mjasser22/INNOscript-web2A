<?php
include '../config.php';

$error = "";
$reservation = null;

// Check if ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Retrieve reservation details based on ID
    $db = Config::getConnexion();
    $query = $db->prepare("SELECT * FROM reservation WHERE id = :id");
    $query->execute(['id' => $id]);
    $reservation = $query->fetch(PDO::FETCH_ASSOC);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (
        isset($_POST["user_name"]) &&
        isset($_POST["phone_number"])
    ) {
        if (
            !empty($_POST['user_name']) &&
            !empty($_POST["phone_number"])
        ) {
            // Update reservation details
            $user_name = $_POST['user_name'];
            $phone_number = $_POST['phone_number'];
            $check_in_date = $_POST['check_in_date'];
            $check_out_date = $_POST['check_out_date'];
            $accomodation_type = $_POST['accomodation_type'];
            $total_price = $_POST['total_price'];

            $db = Config::getConnexion();
            $query = $db->prepare(
                'UPDATE reservation SET 
                    user_name = :user_name, 
                    phone_number = :phone_number, 
                    check_in_date = :check_in_date, 
                    check_out_date = :check_out_date, 
                    accomodation_type = :accomodation_type, 
                    total_price = :total_price
                WHERE id = :id'
            );
            $query->execute([
                'id' => $id,
                'user_name' => $user_name,
                'phone_number' => $phone_number,
                'check_in_date' => $check_in_date,
                'check_out_date' => $check_out_date,
                'accomodation_type' => $accomodation_type,
                'total_price' => $total_price,
            ]);

            // Redirect to list of reservations
            header('Location: ListReservation.php');
            exit();
        } else {
            $error = "Missing information";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Réservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.datatables.net/v/bs5/dt-1.13.4/datatables.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <?php include 'Header.php'; ?>

    <div class="container">
        <?php if ($reservation) : ?>
            <div class="modal-header">
                <h5 class="modal-title" id="updateReservationModalLabel">Modifier Réservation</h5>
            </div>
            <div class="modal-body">
                <div id="error">
                    <?php echo $error; ?>
                </div>
                <form method="POST" id="updateForm" action="" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <div class="col">
                            <label class="form-label">User Name</label>
                            <input type="text" class="form-control" name="user_name" placeholder="Your Name Here" value="<?php echo $reservation['user_name']; ?>">
                        </div>
                        <div class="col">
                            <label class="form-label">Phone Number</label>
                            <input type="text" class="form-control" name="phone_number" placeholder="Your Phone Number Here" value="<?php echo $reservation['phone_number']; ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="form-label">Check-in Date</label>
                        <input type="date" class="form-control" name="check_in_date" value="<?php echo $reservation['check_in_date']; ?>">
                    </div>

                    <div class="row mb-3">
                        <label class="form-label">Check-out Date</label>
                        <input type="date" class="form-control" name="check_out_date" value="<?php echo $reservation['check_out_date']; ?>">
                    </div>

                    <div class="row mb-3">
                        <label class="form-label">Accommodation Type</label>
                        <input type="text" class="form-control" name="accomodation_type" placeholder="Accommodation Type" value="<?php echo $reservation['accomodation_type']; ?>">
                    </div>

                    <div class="row mb-3">
                        <label class="form-label">Total Price</label>
                        <input type="text" class="form-control" name="total_price" placeholder="Total Price" value="<?php echo $reservation['total_price']; ?>">
                    </div>

                    <div>
                        <button type="submit" class="btn btn-primary me-1" id="updateBtn">Valider</button>
                        <button type="reset" class="btn btn-secondary">Annuler</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>

</html>
